#include "Player.h"
#include "Game.h"

int main() 
{
	Game game;
	game.RunGame();

	return 0;
}